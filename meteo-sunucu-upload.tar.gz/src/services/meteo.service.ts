import axios from 'axios';
import { parse } from 'node-html-parser';
import { PNG } from 'pngjs';
import { config } from '../config';
import {
  FORECAST_HOURLY_FIELDS,
  METEO_MAP_LAYERS,
  PRESSURE_LEVEL_BY_ALTITUDE,
  RASTER_BBOX,
  RASTER_GRID_STEP_DEG,
  RASTER_TILE_SIZE,
  STATIONS,
} from '../stations';
import {
  AviationWeatherPayload,
  MeteoCurrentPayload,
  MeteoForecastPayload,
  MeteoMapLayerDefinition,
  MeteoMapPoint,
  MeteoMapSnapshotPayload,
  MeteoRasterGridPayload,
  MeteoRasterGridPoint,
  MeteoRasterStatsPayload,
  MeteoRasterValuePayload,
  MeteoStation,
  RouteSamplePayload,
} from '../types';

type CachedEntry<T> = {
  updatedAt: string;
  data: T;
};

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export class MeteoService {
  private openMeteoTimer?: NodeJS.Timeout;
  private aviationTimer?: NodeJS.Timeout;
  private readonly currentCache = new Map<string, MeteoCurrentPayload>();
  private readonly forecastCache = new Map<string, MeteoForecastPayload>();
  private readonly aviationCache = new Map<string, AviationWeatherPayload>();
  private readonly surfaceProfileCache = new Map<string, CachedEntry<Record<string, unknown>>>();
  private readonly aloftProfileCache = new Map<string, CachedEntry<Record<string, unknown>>>();
  private readonly routeSampleCache = new Map<string, CachedEntry<RouteSamplePayload>>();
  private mapSnapshotCache?: MeteoMapSnapshotPayload;
  private readonly rasterGridInFlight = new Map<string, Promise<MeteoRasterGridPayload>>();
  private readonly rasterGridByHour = new Map<string, MeteoRasterGridPayload>();
  private latestRasterHour?: string;

  start(): void {
    void this.refreshAllStations();
    void this.refreshAllAviation();

    this.openMeteoTimer = setInterval(() => {
      void this.refreshAllStations();
    }, config.openMeteoRefreshMs);
    this.openMeteoTimer.unref?.();

    this.aviationTimer = setInterval(() => {
      void this.refreshAllAviation();
    }, config.aviationRefreshMs);
    this.aviationTimer.unref?.();
  }

  stop(): void {
    if (this.openMeteoTimer) {
      clearInterval(this.openMeteoTimer);
      this.openMeteoTimer = undefined;
    }
    if (this.aviationTimer) {
      clearInterval(this.aviationTimer);
      this.aviationTimer = undefined;
    }
  }

  getStations(): MeteoStation[] {
    return STATIONS;
  }

  getMapLayers(): MeteoMapLayerDefinition[] {
    return METEO_MAP_LAYERS;
  }

  getStation(code: string): MeteoStation | undefined {
    return STATIONS.find((station) => station.code.toUpperCase() === code.toUpperCase());
  }

  private isFresh(updatedAt: string | undefined, ttlMs: number): boolean {
    if (!updatedAt) return false;
    const timestamp = Date.parse(updatedAt);
    if (Number.isNaN(timestamp)) return false;
    return Date.now() - timestamp < ttlMs;
  }

  private parseNumeric(value: unknown): number | null {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string') {
      const parsed = Number(value);
      return Number.isFinite(parsed) ? parsed : null;
    }
    return null;
  }

  private ensureStation(stationCode: string): MeteoStation {
    const station = this.getStation(stationCode);
    if (!station) {
      throw new HttpError(400, `Gecersiz istasyon: ${stationCode}`);
    }
    return station;
  }

  async getCurrentByStation(stationCode: string): Promise<MeteoCurrentPayload> {
    const station = this.ensureStation(stationCode);
    const cached = this.currentCache.get(station.code);
    if (cached && this.isFresh(cached.updatedAt, config.openMeteoRefreshMs)) {
      return {
        ...cached,
        forecast: await this.getCachedForecastByStation(station.code),
      };
    }

    return this.refreshStation(station.code);
  }

  async getForecastByStation(stationCode: string): Promise<MeteoForecastPayload> {
    const station = this.ensureStation(stationCode);
    const cached = this.forecastCache.get(station.code);
    if (cached && this.isFresh(cached.updatedAt, config.openMeteoRefreshMs)) {
      return cached;
    }
    return this.refreshForecastStation(station.code);
  }

  private async getCachedForecastByStation(stationCode: string): Promise<MeteoForecastPayload | null> {
    const cached = this.forecastCache.get(stationCode.toUpperCase());
    if (cached && this.isFresh(cached.updatedAt, config.openMeteoRefreshMs)) {
      return cached;
    }
    try {
      return await this.refreshForecastStation(stationCode);
    } catch {
      return cached ?? null;
    }
  }

  async refreshAllStations(): Promise<void> {
    await Promise.allSettled(
      STATIONS.flatMap((station) => [
        this.refreshStation(station.code),
        this.refreshForecastStation(station.code),
      ]),
    );
    await Promise.allSettled([this.refreshMapSnapshot(), this.refreshRasterGrid()]);
  }

  async refreshAllAviation(): Promise<void> {
    await Promise.allSettled(STATIONS.map((station) => this.refreshAviationWeather(station.code)));
  }

  async refreshStation(stationCode: string): Promise<MeteoCurrentPayload> {
    const station = this.ensureStation(stationCode);
    const url =
      'https://api.open-meteo.com/v1/forecast' +
      `?latitude=${station.lat}` +
      `&longitude=${station.lon}` +
      '&current=temperature_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility,cloud_cover,cloud_base,weather_code,surface_pressure,dew_point_2m,relative_humidity_2m,precipitation' +
      '&timezone=Europe%2FIstanbul';

    try {
      const response = await axios.get(url, { timeout: 15000 });
      const data = response.data ?? {};

      const payload: MeteoCurrentPayload = {
        station,
        updatedAt: new Date().toISOString(),
        current: data.current ?? {},
        currentUnits: data.current_units ?? null,
        forecast: await this.getCachedForecastByStation(station.code),
        elevation: this.parseNumeric(data.elevation),
        latitude: this.parseNumeric(data.latitude) ?? undefined,
        longitude: this.parseNumeric(data.longitude) ?? undefined,
      };

      this.currentCache.set(station.code, payload);
      return payload;
    } catch (error) {
      const cached = this.currentCache.get(station.code);
      if (cached) return cached;
      throw new HttpError(503, `Open-Meteo current verisi alinamadi: ${station.code}`);
    }
  }

  async refreshForecastStation(stationCode: string): Promise<MeteoForecastPayload> {
    const station = this.ensureStation(stationCode);
    const url =
      'https://api.open-meteo.com/v1/forecast' +
      `?latitude=${station.lat}` +
      `&longitude=${station.lon}` +
      `&hourly=${FORECAST_HOURLY_FIELDS}` +
      '&forecast_hours=168' +
      '&temperature_unit=celsius' +
      '&wind_speed_unit=kn' +
      '&precipitation_unit=mm' +
      '&timezone=Europe%2FIstanbul';

    try {
      const response = await axios.get(url, { timeout: 15000 });
      const data = response.data ?? {};

      const payload: MeteoForecastPayload = {
        station,
        updatedAt: new Date().toISOString(),
        hourly: data.hourly ?? {},
        hourlyUnits: data.hourly_units ?? null,
        elevation: this.parseNumeric(data.elevation),
        latitude: this.parseNumeric(data.latitude) ?? undefined,
        longitude: this.parseNumeric(data.longitude) ?? undefined,
      };

      this.forecastCache.set(station.code, payload);
      const current = this.currentCache.get(station.code);
      if (current) {
        this.currentCache.set(station.code, { ...current, forecast: payload });
      }
      return payload;
    } catch (error) {
      const cached = this.forecastCache.get(station.code);
      if (cached) return cached;
      throw new HttpError(503, `Open-Meteo forecast verisi alinamadi: ${station.code}`);
    }
  }

  async getAviationWeather(stationCode: string, preferredSource?: string): Promise<AviationWeatherPayload> {
    const station = this.ensureStation(stationCode);
    const cached = this.aviationCache.get(station.code);
    if (cached && this.isFresh(cached.updatedAt, config.aviationRefreshMs)) {
      return cached;
    }
    return this.refreshAviationWeather(station.code, preferredSource);
  }

  async refreshAviationWeather(stationCode: string, preferredSource = 'hazerfan'): Promise<AviationWeatherPayload> {
    const station = this.ensureStation(stationCode);
    const order = preferredSource === 'noaa' ? ['noaa', 'hazerfan'] : ['hazerfan', 'noaa'];
    const errors: string[] = [];

    for (let index = 0; index < order.length; index += 1) {
      const source = order[index] as 'hazerfan' | 'noaa';
      try {
        const payload =
          source === 'hazerfan'
            ? await this.fetchHazerfanLikeWeather(station)
            : await this.fetchNoaaWeather(station);

        const withMeta: AviationWeatherPayload = {
          ...payload,
          fallbackUsed: index > 0,
        };
        this.aviationCache.set(station.code, withMeta);
        return withMeta;
      } catch (error) {
        errors.push(`${source}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }

    const cached = this.aviationCache.get(station.code);
    if (cached) return cached;
    throw new HttpError(503, `METAR/TAF verisi alinamadi: ${errors.join(' | ')}`);
  }

  private async fetchHazerfanLikeWeather(station: MeteoStation): Promise<AviationWeatherPayload> {
    const url = config.hazerfanUrlTemplate.replace('{station}', encodeURIComponent(station.code));
    const response = await axios.get<string>(url, { timeout: 15000, responseType: 'text' });
    const root = parse(response.data);
    const pageText = root.innerText;
    const metar = this.extractSection(pageText, 'METAR', 'TAF');
    const taf = this.extractSection(pageText, 'TAF');

    if (!metar && !taf) {
      throw new Error('Birincil kaynakta METAR/TAF bulunamadi');
    }

    return {
      station,
      updatedAt: new Date().toISOString(),
      source: 'hazerfan',
      metar,
      taf,
      fallbackUsed: false,
    };
  }

  private extractSection(text: string, startToken: string, endToken?: string): string | null {
    const startIndex = text.indexOf(startToken);
    if (startIndex === -1) return null;

    const afterStart = text.substring(startIndex);
    const copyrightIndex = afterStart.indexOf('©');
    const endIndex = endToken ? afterStart.indexOf(endToken) : -1;

    let cutIndex = afterStart.length > 500 ? 500 : afterStart.length;
    if (endIndex !== -1) {
      cutIndex = endIndex;
    } else if (copyrightIndex !== -1) {
      cutIndex = copyrightIndex;
    }

    return afterStart.substring(0, cutIndex).replace(/\s+/g, ' ').trim();
  }

  private async fetchNoaaWeather(station: MeteoStation): Promise<AviationWeatherPayload> {
    const metarUrl = `https://aviationweather.gov/api/data/metar?ids=${station.code}&format=json`;
    const tafUrl = `https://aviationweather.gov/api/data/taf?ids=${station.code}&format=json`;

    const [metarResponse, tafResponse] = await Promise.all([
      axios.get<Array<Record<string, unknown>>>(metarUrl, { timeout: 15000 }),
      axios.get<Array<Record<string, unknown>>>(tafUrl, { timeout: 15000 }),
    ]);

    const metar = metarResponse.data?.[0]?.rawOb;
    const taf = tafResponse.data?.[0]?.rawTAF;

    if (!metar && !taf) {
      throw new Error('NOAA kaynagi bos dondu');
    }

    return {
      station,
      updatedAt: new Date().toISOString(),
      source: 'noaa',
      metar: typeof metar === 'string' ? metar : null,
      taf: typeof taf === 'string' ? taf : null,
      fallbackUsed: false,
    };
  }

  async getStationSurfaceProfile(stationCode: string): Promise<Record<string, unknown>> {
    const station = this.ensureStation(stationCode);
    const cacheKey = station.code;
    const cached = this.surfaceProfileCache.get(cacheKey);
    if (cached && this.isFresh(cached.updatedAt, config.openMeteoRefreshMs)) {
      return cached.data;
    }

    const url =
      'https://api.open-meteo.com/v1/forecast' +
      `?latitude=${station.lat}` +
      `&longitude=${station.lon}` +
      '&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,wind_direction_10m' +
      '&hourly=temperature_2m,precipitation_probability,wind_speed_10m,wind_direction_10m' +
      '&timezone=Europe%2FIstanbul' +
      '&forecast_days=3';

    const response = await axios.get<Record<string, unknown>>(url, { timeout: 15000 });
    const entry = { updatedAt: new Date().toISOString(), data: response.data };
    this.surfaceProfileCache.set(cacheKey, entry);
    return entry.data;
  }

  async getStationAloftProfile(stationCode: string): Promise<Record<string, unknown>> {
    const station = this.ensureStation(stationCode);
    const cacheKey = station.code;
    const cached = this.aloftProfileCache.get(cacheKey);
    if (cached && this.isFresh(cached.updatedAt, config.openMeteoRefreshMs)) {
      return cached.data;
    }

    const hourly = [
      'temperature_925hPa',
      'temperature_850hPa',
      'temperature_800hPa',
      'temperature_775hPa',
      'temperature_750hPa',
      'temperature_725hPa',
      'temperature_700hPa',
      'wind_speed_925hPa',
      'wind_speed_850hPa',
      'wind_speed_800hPa',
      'wind_speed_775hPa',
      'wind_speed_750hPa',
      'wind_speed_725hPa',
      'wind_speed_700hPa',
      'wind_direction_925hPa',
      'wind_direction_850hPa',
      'wind_direction_800hPa',
      'wind_direction_775hPa',
      'wind_direction_750hPa',
      'wind_direction_725hPa',
      'wind_direction_700hPa',
      'relative_humidity_925hPa',
      'relative_humidity_850hPa',
      'relative_humidity_800hPa',
      'relative_humidity_775hPa',
      'relative_humidity_750hPa',
      'relative_humidity_725hPa',
      'relative_humidity_700hPa',
      'cape',
      'lifted_index',
    ].join(',');

    const url =
      'https://api.open-meteo.com/v1/forecast' +
      `?latitude=${station.lat}` +
      `&longitude=${station.lon}` +
      '&current=temperature_2m,surface_pressure' +
      `&hourly=${hourly}` +
      '&timezone=Europe%2FIstanbul' +
      '&forecast_days=1';

    const response = await axios.get<Record<string, unknown>>(url, { timeout: 15000 });
    const entry = { updatedAt: new Date().toISOString(), data: response.data };
    this.aloftProfileCache.set(cacheKey, entry);
    return entry.data;
  }

  async getRouteSample(latitude: number, longitude: number, altitude: string): Promise<RouteSamplePayload> {
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      throw new HttpError(400, 'Gecersiz koordinat');
    }

    const normalizedAltitude = altitude || 'SFC';
    const cacheKey = `${latitude.toFixed(3)}:${longitude.toFixed(3)}:${normalizedAltitude}`;
    const cached = this.routeSampleCache.get(cacheKey);
    if (cached && this.isFresh(cached.updatedAt, config.openMeteoRefreshMs)) {
      return cached.data;
    }

    let url: string;
    if (normalizedAltitude === 'SFC') {
      url =
        'https://api.open-meteo.com/v1/forecast' +
        `?latitude=${latitude}` +
        `&longitude=${longitude}` +
        '&current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,precipitation,cloud_cover' +
        '&timezone=Europe%2FIstanbul';
    } else {
      const pressureLevel = PRESSURE_LEVEL_BY_ALTITUDE[normalizedAltitude];
      if (!pressureLevel) {
        throw new HttpError(400, `Desteklenmeyen altitude: ${normalizedAltitude}`);
      }
      url =
        'https://api.open-meteo.com/v1/forecast' +
        `?latitude=${latitude}` +
        `&longitude=${longitude}` +
        '&current=precipitation,cloud_cover' +
        `&hourly=temperature_${pressureLevel}hPa,relative_humidity_${pressureLevel}hPa,wind_speed_${pressureLevel}hPa,wind_direction_${pressureLevel}hPa` +
        '&forecast_hours=1' +
        '&timezone=Europe%2FIstanbul';
    }

    const response = await axios.get<Record<string, unknown>>(url, { timeout: 15000 });
    const data = response.data;
    const current = (data.current as Record<string, unknown> | undefined) ?? {};
    const hourly = (data.hourly as Record<string, unknown> | undefined) ?? {};

    let temperature = 0;
    let humidity = 0;
    let windSpeed = 0;
    let windDirection = 0;

    if (normalizedAltitude === 'SFC') {
      temperature = this.parseNumeric(current.temperature_2m) ?? 0;
      humidity = this.parseNumeric(current.relative_humidity_2m) ?? 0;
      windSpeed = this.parseNumeric(current.wind_speed_10m) ?? 0;
      windDirection = this.parseNumeric(current.wind_direction_10m) ?? 0;
    } else {
      const pressureLevel = PRESSURE_LEVEL_BY_ALTITUDE[normalizedAltitude];
      const temperatureSeries = hourly[`temperature_${pressureLevel}hPa`];
      const humiditySeries = hourly[`relative_humidity_${pressureLevel}hPa`];
      const windSpeedSeries = hourly[`wind_speed_${pressureLevel}hPa`];
      const windDirectionSeries = hourly[`wind_direction_${pressureLevel}hPa`];

      temperature = Array.isArray(temperatureSeries) ? this.parseNumeric(temperatureSeries[0]) ?? 0 : 0;
      humidity = Array.isArray(humiditySeries) ? this.parseNumeric(humiditySeries[0]) ?? 0 : 0;
      windSpeed = Array.isArray(windSpeedSeries) ? this.parseNumeric(windSpeedSeries[0]) ?? 0 : 0;
      windDirection = Array.isArray(windDirectionSeries) ? this.parseNumeric(windDirectionSeries[0]) ?? 0 : 0;
    }

    const payload: RouteSamplePayload = {
      latitude,
      longitude,
      altitude: normalizedAltitude,
      elevation: this.parseNumeric(data.elevation) ?? 0,
      temperature,
      humidity,
      windSpeed,
      windDirection,
      precipitation: this.parseNumeric(current.precipitation),
      cloudCover: this.parseNumeric(current.cloud_cover),
    };

    this.routeSampleCache.set(cacheKey, {
      updatedAt: new Date().toISOString(),
      data: payload,
    });

    return payload;
  }

  async getMapSnapshot(forceRefresh = false, atIso?: string): Promise<MeteoMapSnapshotPayload> {
    if (atIso && atIso.trim().length > 0) {
      return this.buildTemporalMapSnapshot(atIso);
    }

    if (!forceRefresh && this.mapSnapshotCache && this.isFresh(this.mapSnapshotCache.generatedAt, config.openMeteoRefreshMs)) {
      return this.mapSnapshotCache;
    }

    return this.refreshMapSnapshot();
  }

  async refreshMapSnapshot(): Promise<MeteoMapSnapshotPayload> {
    const points: MeteoMapPoint[] = [];

    for (const station of STATIONS) {
      let current = this.currentCache.get(station.code);
      if (!current || !this.isFresh(current.updatedAt, config.openMeteoRefreshMs)) {
        try {
          current = await this.refreshStation(station.code);
        } catch {
          current = this.currentCache.get(station.code);
        }
      }

      if (!current) continue;

      const values: Record<string, number | null> = {};
      for (const layer of METEO_MAP_LAYERS) {
        values[layer.field] = this.parseNumeric(current.current[layer.field]);
      }

      points.push({
        station,
        updatedAt: current.updatedAt,
        latitude: station.lat,
        longitude: station.lon,
        values,
      });
    }

    this.mapSnapshotCache = {
      generatedAt: new Date().toISOString(),
      layers: METEO_MAP_LAYERS,
      points,
    };

    return this.mapSnapshotCache;
  }

  private buildRange(start: number, end: number, step: number): number[] {
    const values: number[] = [];
    for (let value = start; value <= end + 1e-9; value += step) {
      values.push(Number(value.toFixed(4)));
    }
    return values;
  }

  private toHourIso(value: string | Date): string {
    const date = typeof value === 'string' ? new Date(value) : new Date(value.getTime());
    date.setUTCMinutes(0, 0, 0);
    return date.toISOString();
  }

  async refreshRasterGrid(hour?: string): Promise<MeteoRasterGridPayload> {
    const targetHourIso = this.toHourIso(hour ?? new Date());
    const existing = this.rasterGridByHour.get(targetHourIso);
    if (existing) {
      this.latestRasterHour = targetHourIso;
      return existing;
    }

    const inFlight = this.rasterGridInFlight.get(targetHourIso);
    if (inFlight) return inFlight;

    const refreshPromise = (async (): Promise<MeteoRasterGridPayload> => {
      const latitudes = this.buildRange(RASTER_BBOX.south, RASTER_BBOX.north, RASTER_GRID_STEP_DEG);
      const longitudes = this.buildRange(RASTER_BBOX.west, RASTER_BBOX.east, RASTER_GRID_STEP_DEG);

      const latList: number[] = [];
      const lonList: number[] = [];
      for (const lat of latitudes) {
        for (const lon of longitudes) {
          latList.push(lat);
          lonList.push(lon);
        }
      }

      const params = new URLSearchParams({
        latitude: latList.join(','),
        longitude: lonList.join(','),
        hourly: METEO_MAP_LAYERS.map((layer) => layer.field).join(','),
        forecast_hours: '1',
        timezone: 'UTC',
      });

      if (hour) {
        params.set('start_hour', targetHourIso);
        params.set('end_hour', targetHourIso);
      }

      const url = `https://api.open-meteo.com/v1/forecast?${params.toString()}`;
      const response = await axios.get(url, { timeout: 30000 });
      const payloads = Array.isArray(response.data) ? response.data : [response.data];

      const points: MeteoRasterGridPoint[] = payloads.map((entry) => {
        const hourly = (entry?.hourly ?? {}) as Record<string, unknown>;
        const values: Record<string, number | null> = {};
        for (const layer of METEO_MAP_LAYERS) {
          const series = hourly[layer.field];
          values[layer.field] = Array.isArray(series) && series.length > 0 ? this.parseNumeric(series[0]) : null;
        }
        return {
          latitude: this.parseNumeric(entry?.latitude) ?? 0,
          longitude: this.parseNumeric(entry?.longitude) ?? 0,
          values,
        };
      });

      const payload: MeteoRasterGridPayload = {
        generatedAt: new Date().toISOString(),
        hourIso: targetHourIso,
        bbox: RASTER_BBOX,
        stepDegrees: RASTER_GRID_STEP_DEG,
        latitudes,
        longitudes,
        points,
      };

      this.rasterGridByHour.set(targetHourIso, payload);
      this.latestRasterHour = targetHourIso;
      return payload;
    })();

    this.rasterGridInFlight.set(targetHourIso, refreshPromise);
    try {
      return await refreshPromise;
    } catch (error) {
      if (this.latestRasterHour) {
        const fallback = this.rasterGridByHour.get(this.latestRasterHour);
        if (fallback) return fallback;
      }
      throw new HttpError(503, 'Open-Meteo raster grid verisi alinamadi');
    } finally {
      this.rasterGridInFlight.delete(targetHourIso);
    }
  }

  async getRasterGridLatest(): Promise<MeteoRasterGridPayload> {
    if (this.latestRasterHour) {
      const existing = this.rasterGridByHour.get(this.latestRasterHour);
      if (existing) return existing;
    }
    return this.refreshRasterGrid();
  }

  private toDateOrThrow(atIso?: string): Date {
    if (!atIso || atIso.trim().length === 0) return new Date();
    const date = new Date(atIso);
    if (Number.isNaN(date.getTime())) {
      throw new HttpError(400, 'at gecersiz tarih formatinda');
    }
    return date;
  }

  private async resolveTemporalContext(atIso?: string): Promise<{
    gridA: MeteoRasterGridPayload;
    gridB: MeteoRasterGridPayload | null;
    blend: number;
    hourIso: string;
  }> {
    if (!atIso || atIso.trim().length === 0) {
      const grid = await this.getRasterGridLatest();
      return { gridA: grid, gridB: null, blend: 0, hourIso: grid.hourIso };
    }

    const target = this.toDateOrThrow(atIso);
    const hourStart = new Date(target.getTime());
    hourStart.setUTCMinutes(0, 0, 0);
    const nextHour = new Date(hourStart.getTime() + 60 * 60 * 1000);
    const blend = Math.max(0, Math.min(1, (target.getUTCMinutes() * 60 + target.getUTCSeconds()) / 3600));

    const gridA = await this.refreshRasterGrid(hourStart.toISOString());
    if (blend <= 0.001) {
      return { gridA, gridB: null, blend: 0, hourIso: gridA.hourIso };
    }

    const gridB = await this.refreshRasterGrid(nextHour.toISOString());
    return { gridA, gridB, blend, hourIso: gridA.hourIso };
  }

  private gridValue(grid: MeteoRasterGridPayload, field: string, latIdx: number, lonIdx: number): number | null {
    const lonCount = grid.longitudes.length;
    const pointIdx = latIdx * lonCount + lonIdx;
    return this.parseNumeric(grid.points[pointIdx]?.values[field]);
  }

  private bilinearSample(grid: MeteoRasterGridPayload, field: string, latitude: number, longitude: number): number | null {
    const lonCount = grid.longitudes.length;
    const latCount = grid.latitudes.length;
    if (!lonCount || !latCount) return null;

    const fx = (longitude - RASTER_BBOX.west) / grid.stepDegrees;
    const fy = (latitude - RASTER_BBOX.south) / grid.stepDegrees;

    const x0 = Math.max(0, Math.min(lonCount - 1, Math.floor(fx)));
    const y0 = Math.max(0, Math.min(latCount - 1, Math.floor(fy)));
    const x1 = Math.max(0, Math.min(lonCount - 1, x0 + 1));
    const y1 = Math.max(0, Math.min(latCount - 1, y0 + 1));
    const tx = Math.max(0, Math.min(1, fx - x0));
    const ty = Math.max(0, Math.min(1, fy - y0));

    const v00 = this.gridValue(grid, field, y0, x0);
    const v10 = this.gridValue(grid, field, y0, x1);
    const v01 = this.gridValue(grid, field, y1, x0);
    const v11 = this.gridValue(grid, field, y1, x1);

    const weighted: Array<{ value: number; weight: number }> = [];
    if (v00 != null) weighted.push({ value: v00, weight: (1 - tx) * (1 - ty) });
    if (v10 != null) weighted.push({ value: v10, weight: tx * (1 - ty) });
    if (v01 != null) weighted.push({ value: v01, weight: (1 - tx) * ty });
    if (v11 != null) weighted.push({ value: v11, weight: tx * ty });

    if (weighted.length === 0) return null;
    const totalWeight = weighted.reduce((sum, item) => sum + item.weight, 0);
    if (totalWeight <= 0) return weighted[0].value;
    return weighted.reduce((sum, item) => sum + item.value * item.weight, 0) / totalWeight;
  }

  private blendValues(a: number | null, b: number | null, t: number): number | null {
    if (a == null && b == null) return null;
    if (a == null) return b;
    if (b == null) return a;
    return a * (1 - t) + b * t;
  }

  private sampleTemporalValue(
    field: string,
    latitude: number,
    longitude: number,
    context: { gridA: MeteoRasterGridPayload; gridB: MeteoRasterGridPayload | null; blend: number },
  ): number | null {
    const a = this.bilinearSample(context.gridA, field, latitude, longitude);
    if (!context.gridB || context.blend <= 0.001) return a;
    const b = this.bilinearSample(context.gridB, field, latitude, longitude);
    return this.blendValues(a, b, context.blend);
  }

  private buildTemporalMapSnapshot = async (atIso: string): Promise<MeteoMapSnapshotPayload> => {
    const temporalContext = await this.resolveTemporalContext(atIso);
    const points: MeteoMapPoint[] = STATIONS.map((station) => {
      const values: Record<string, number | null> = {};
      for (const layer of METEO_MAP_LAYERS) {
        values[layer.field] = this.sampleTemporalValue(layer.field, station.lat, station.lon, temporalContext);
      }

      return {
        station,
        updatedAt: temporalContext.hourIso,
        latitude: station.lat,
        longitude: station.lon,
        values,
      };
    });

    return {
      generatedAt: new Date().toISOString(),
      layers: METEO_MAP_LAYERS,
      points,
    };
  };

  private lonToTileX(lon: number, z: number): number {
    return ((lon + 180) / 360) * Math.pow(2, z);
  }

  private latToTileY(lat: number, z: number): number {
    const rad = (lat * Math.PI) / 180;
    return ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * Math.pow(2, z);
  }

  private tileLon(x: number, z: number): number {
    return (x / Math.pow(2, z)) * 360 - 180;
  }

  private tileLat(y: number, z: number): number {
    const n = Math.PI - (2 * Math.PI * y) / Math.pow(2, z);
    return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
  }

  private layerColor(layerId: string, value: number): [number, number, number, number] {
    const clamp = (input: number, min: number, max: number) => Math.max(min, Math.min(max, input));
    const lerp = (start: number, end: number, t: number) => Math.round(start + (end - start) * t);
    const mix = (a: [number, number, number], b: [number, number, number], t: number): [number, number, number] => [
      lerp(a[0], b[0], t),
      lerp(a[1], b[1], t),
      lerp(a[2], b[2], t),
    ];

    let t = 0;
    let color: [number, number, number] = [120, 120, 120];
    switch (layerId) {
      case 'om_cloud_cover':
        t = clamp(value / 100, 0, 1);
        color = mix([191, 219, 254], [30, 64, 175], t);
        break;
      case 'om_wind_speed':
        t = clamp(value / 80, 0, 1);
        color = mix([187, 247, 208], [15, 118, 110], t);
        break;
      case 'om_wind_gust':
        t = clamp(value / 100, 0, 1);
        color = mix([254, 215, 170], [194, 65, 12], t);
        break;
      case 'om_precipitation':
        t = clamp(value / 20, 0, 1);
        color = mix([165, 243, 252], [30, 64, 175], t);
        break;
      case 'om_temperature':
        t = clamp((value + 20) / 60, 0, 1);
        color = mix([59, 130, 246], [220, 38, 38], t);
        break;
      default:
        color = [90, 90, 90];
        break;
    }

    return [color[0], color[1], color[2], 150];
  }

  async getRasterTile(layerId: string, z: number, x: number, y: number, atIso?: string): Promise<Buffer> {
    const layer = METEO_MAP_LAYERS.find((entry) => entry.id === layerId);
    if (!layer) {
      throw new HttpError(400, `Gecersiz katman: ${layerId}`);
    }

    let temporalContext: Awaited<ReturnType<MeteoService['resolveTemporalContext']>>;
    try {
      temporalContext = await this.resolveTemporalContext(atIso);
    } catch {
      const empty = new PNG({ width: RASTER_TILE_SIZE, height: RASTER_TILE_SIZE });
      return PNG.sync.write(empty);
    }

    const westTile = this.tileLon(x, z);
    const eastTile = this.tileLon(x + 1, z);
    const northTile = this.tileLat(y, z);
    const southTile = this.tileLat(y + 1, z);

    if (
      eastTile < RASTER_BBOX.west ||
      westTile > RASTER_BBOX.east ||
      northTile < RASTER_BBOX.south ||
      southTile > RASTER_BBOX.north
    ) {
      const empty = new PNG({ width: RASTER_TILE_SIZE, height: RASTER_TILE_SIZE });
      return PNG.sync.write(empty);
    }

    const png = new PNG({ width: RASTER_TILE_SIZE, height: RASTER_TILE_SIZE });
    for (let py = 0; py < RASTER_TILE_SIZE; py += 1) {
      for (let px = 0; px < RASTER_TILE_SIZE; px += 1) {
        const worldX = x + px / RASTER_TILE_SIZE;
        const worldY = y + py / RASTER_TILE_SIZE;
        const lon = this.tileLon(worldX, z);
        const lat = this.tileLat(worldY, z);
        const pngIdx = (py * RASTER_TILE_SIZE + px) * 4;

        if (lon < RASTER_BBOX.west || lon > RASTER_BBOX.east || lat < RASTER_BBOX.south || lat > RASTER_BBOX.north) {
          png.data[pngIdx + 3] = 0;
          continue;
        }

        const value = this.sampleTemporalValue(layer.field, lat, lon, temporalContext);
        if (value == null) {
          png.data[pngIdx + 3] = 0;
          continue;
        }

        const [r, g, b, a] = this.layerColor(layerId, value);
        png.data[pngIdx] = r;
        png.data[pngIdx + 1] = g;
        png.data[pngIdx + 2] = b;
        png.data[pngIdx + 3] = a;
      }
    }

    return PNG.sync.write(png);
  }

  async getRasterValue(layerId: string, latitude: number, longitude: number, atIso?: string): Promise<MeteoRasterValuePayload> {
    const layer = METEO_MAP_LAYERS.find((entry) => entry.id === layerId);
    if (!layer) {
      throw new HttpError(400, `Gecersiz katman: ${layerId}`);
    }

    const temporalContext = await this.resolveTemporalContext(atIso);
    return {
      layerId,
      field: layer.field,
      unit: layer.unit,
      hourIso: temporalContext.hourIso,
      query: { latitude, longitude },
      sample: {
        latitude,
        longitude,
        value: this.sampleTemporalValue(layer.field, latitude, longitude, temporalContext),
      },
    };
  }

  async getRasterStats(
    layerId: string,
    north: number,
    east: number,
    south: number,
    west: number,
    atIso?: string,
  ): Promise<MeteoRasterStatsPayload> {
    const layer = METEO_MAP_LAYERS.find((entry) => entry.id === layerId);
    if (!layer) {
      throw new HttpError(400, `Gecersiz katman: ${layerId}`);
    }

    const temporalContext = await this.resolveTemporalContext(atIso);
    const grid = temporalContext.gridA;
    const n = Math.max(north, south);
    const s = Math.min(north, south);
    const e = Math.max(east, west);
    const w = Math.min(east, west);

    let min = Number.POSITIVE_INFINITY;
    let max = Number.NEGATIVE_INFINITY;
    let sum = 0;
    let sampleCount = 0;

    for (const point of grid.points) {
      if (point.latitude > n || point.latitude < s || point.longitude > e || point.longitude < w) {
        continue;
      }

      const value = this.sampleTemporalValue(layer.field, point.latitude, point.longitude, temporalContext);
      if (value == null || !Number.isFinite(value)) continue;
      min = Math.min(min, value);
      max = Math.max(max, value);
      sum += value;
      sampleCount += 1;
    }

    return {
      layerId,
      field: layer.field,
      unit: layer.unit,
      hourIso: temporalContext.hourIso,
      bbox: { north: n, east: e, south: s, west: w },
      min: sampleCount > 0 ? min : null,
      max: sampleCount > 0 ? max : null,
      mean: sampleCount > 0 ? sum / sampleCount : null,
      sampleCount,
    };
  }
}